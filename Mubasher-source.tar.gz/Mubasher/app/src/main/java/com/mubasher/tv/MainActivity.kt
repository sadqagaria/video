package com.mubasher.tv

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/**
 * A receiver-style player. The application does not host or decrypt channels.
 * Online lists are provided by IPTV-org. Some streams may be offline/geoblocked.
 */
@androidx.annotation.OptIn(markerClass = [UnstableApi::class])
class MainActivity : AppCompatActivity() {

    companion object {
        private const val ALL = "جميع القنوات"
        private const val DEFAULT_UA = "Mozilla/5.0 (Linux; Android 10) Mubasher/1.1"
        private const val PANEL_TIMEOUT = 10_000L
        private const val BANNER_TIMEOUT = 4_000L
        private const val MAX_PLAYLIST_BYTES = 20_000_000
        private const val BASE_URL = "https://iptv-org.github.io/iptv/"
    }

    private data class PlaylistSource(val label: String, val url: String?)

    // Keep the first source focused on the Arabic audience. The complete worldwide
    // lists are also available without recompiling or adding any credentials.
    private val sources = listOf(
        PlaylistSource("الوطن العربي", "${BASE_URL}regions/arab.m3u"),
        PlaylistSource("اللغة العربية", "${BASE_URL}languages/ara.m3u"),
        PlaylistSource("مصر", "${BASE_URL}countries/eg.m3u"),
        PlaylistSource("السعودية", "${BASE_URL}countries/sa.m3u"),
        PlaylistSource("الإمارات", "${BASE_URL}countries/ae.m3u"),
        PlaylistSource("قطر", "${BASE_URL}countries/qa.m3u"),
        PlaylistSource("دول الخليج", "${BASE_URL}regions/gcc.m3u"),
        PlaylistSource("شمال أفريقيا", "${BASE_URL}regions/maghreb.m3u"),
        PlaylistSource("العالم كله - حسب الدولة", "${BASE_URL}index.country.m3u"),
        PlaylistSource("العالم كله - حسب التصنيف", "${BASE_URL}index.category.m3u"),
        PlaylistSource("قنوات مجانية مختارة - Free-TV",
            "https://raw.githubusercontent.com/Free-TV/IPTV/master/playlist.m3u8"),
        PlaylistSource("قنوات الأخبار", "${BASE_URL}categories/news.m3u"),
        PlaylistSource("قنوات الرياضة", "${BASE_URL}categories/sports.m3u"),
        PlaylistSource("القنوات الدينية", "${BASE_URL}categories/religious.m3u"),
        PlaylistSource("قنوات الأطفال", "${BASE_URL}categories/kids.m3u"),
        PlaylistSource("القنوات الوثائقية", "${BASE_URL}categories/documentary.m3u"),
        PlaylistSource("ملف القنوات الاحتياطي", null)
    )

    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var panel: View
    private lateinit var list: RecyclerView
    private lateinit var groupTitle: TextView
    private lateinit var countText: TextView
    private lateinit var sid: TextView
    private lateinit var banner: View
    private lateinit var bNum: TextView
    private lateinit var bName: TextView
    private lateinit var bGroup: TextView
    private lateinit var bClock: TextView
    private lateinit var numberBox: TextView
    private lateinit var status: TextView

    private val adapter = ChannelAdapter { position ->
        if (position in visible.indices) {
            adapter.selected = position
            playChannel(visible[position])
        }
    }
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("mubasher", MODE_PRIVATE) }

    private var all: List<Channel> = emptyList()
    private var groups: List<String> = listOf(ALL)
    private var groupIdx = 0
    private var visible: List<Channel> = emptyList()
    private var playing: Channel? = null
    private var typed = ""
    private var searchQuery = ""
    private var loadJob: Job? = null
    private var sourceIndex = 0

    private val hidePanel = Runnable { panel.visibility = View.GONE }
    private val hideBanner = Runnable { banner.visibility = View.GONE }
    private val hideStatus = Runnable { status.visibility = View.GONE }
    private val commitNumber = Runnable { jumpToNumber() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        sourceIndex = prefs.getInt("source_index", 0).coerceIn(0, sources.size)
        goFullscreen()
        bindViews()
        setupPlayer()
        setupControls()
        loadPlaylist()
    }

    private fun goFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun bindViews() {
        playerView = findViewById(R.id.player)
        panel = findViewById(R.id.panel)
        list = findViewById(R.id.list)
        groupTitle = findViewById(R.id.groupTitle)
        countText = findViewById(R.id.count)
        sid = findViewById(R.id.sid)
        banner = findViewById(R.id.banner)
        bNum = findViewById(R.id.bNum)
        bName = findViewById(R.id.bName)
        bGroup = findViewById(R.id.bGroup)
        bClock = findViewById(R.id.bClock)
        numberBox = findViewById(R.id.numberBox)
        status = findViewById(R.id.status)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
    }

    private fun setupPlayer() {
        player = ExoPlayer.Builder(this).build()
        playerView.player = player
        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                showStatus("لا توجد إشارة", autoHide = false)
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) {
                    handler.removeCallbacks(hideStatus)
                    status.visibility = View.GONE
                }
            }
        })
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupControls() {
        val gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                togglePanel()
                return true
            }

            override fun onFling(
                e1: MotionEvent?,
                e2: MotionEvent,
                velocityX: Float,
                velocityY: Float
            ): Boolean {
                if (abs(velocityY) > abs(velocityX)) {
                    zap(if (velocityY < 0) 1 else -1)
                    return true
                }
                return false
            }
        })
        playerView.setOnTouchListener { _, event ->
            gestures.onTouchEvent(event)
            true
        }
        findViewById<View>(R.id.prevGroup).setOnClickListener { switchGroup(-1) }
        findViewById<View>(R.id.nextGroup).setOnClickListener { switchGroup(1) }
        findViewById<View>(R.id.settingsBtn).setOnClickListener { openSources() }
        findViewById<View>(R.id.searchBtn).setOnClickListener { openSearch() }
        findViewById<View>(R.id.header).setOnLongClickListener { openSources(); true }
        list.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                if (panel.visibility == View.VISIBLE) keepPanel()
            }
        })
    }

    private fun sourceUrl(): String? =
        if (sourceIndex == sources.size) prefs.getString("custom_url", "").orEmpty()
        else sources[sourceIndex].url

    private fun sourceLabel(): String =
        if (sourceIndex == sources.size) "رابط M3U خاص"
        else sources[sourceIndex].label

    private fun sourceKey(): String = sourceUrl() ?: "built-in"

    private fun loadPlaylist() {
        loadJob?.cancel()
        showStatus("جاري تحميل ${sourceLabel()}…", autoHide = false)
        val url = sourceUrl()
        val key = sourceKey()

        loadJob = lifecycleScope.launch {
            val fetched = withContext(Dispatchers.IO) {
                try {
                    if (url.isNullOrBlank()) null else download(url)
                } catch (error: CancellationException) {
                    throw error
                } catch (_: Exception) {
                    null
                }
            }
            val remote = fetched?.let { M3uParser.parse(it) }.orEmpty()
            val fromBackup = url != null && remote.isEmpty()
            val channels = if (remote.isNotEmpty()) remote else withContext(Dispatchers.IO) {
                M3uParser.parse(
                    assets.open("channels.m3u").bufferedReader(Charsets.UTF_8)
                        .use { it.readText() }
                )
            }

            if (channels.isEmpty()) {
                showStatus("لا توجد قنوات. اضغط info لاختيار قائمة.", autoHide = false)
                showPanel()
                return@launch
            }

            all = channels
            groups = listOf(ALL) + channels.map { it.group }.distinct()
            groupIdx = 0
            searchQuery = ""
            playing = null
            player.stop()
            applyGroup()

            val resumeUrl = prefs.getString("last_url", "")
                .takeIf { prefs.getString("last_source", "") == key }
            val initial = channels.firstOrNull { it.url == resumeUrl } ?: channels.first()
            playChannel(initial)
            if (fromBackup) {
                showStatus("تعذر تحميل الإنترنت. تم فتح القائمة الاحتياطية.")
            }
        }
    }

    private fun download(url: String): String {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 15_000
            connection.readTimeout = 25_000
            connection.instanceFollowRedirects = true
            connection.setRequestProperty("User-Agent", DEFAULT_UA)
            if (connection.responseCode !in 200..299) {
                throw IllegalStateException("HTTP ${connection.responseCode}")
            }
            if (connection.contentLengthLong > MAX_PLAYLIST_BYTES) {
                throw IllegalStateException("Playlist too large")
            }
            val buffer = ByteArray(16_384)
            val content = java.io.ByteArrayOutputStream()
            connection.inputStream.use { stream ->
                while (true) {
                    val n = stream.read(buffer)
                    if (n < 0) break
                    if (content.size() + n > MAX_PLAYLIST_BYTES) {
                        throw IllegalStateException("Playlist too large")
                    }
                    content.write(buffer, 0, n)
                }
            }
            return content.toString("UTF-8")
        } finally {
            connection.disconnect()
        }
    }

    private fun playChannel(channel: Channel) {
        playing = channel
        prefs.edit()
            .putString("last_source", sourceKey())
            .putString("last_url", channel.url)
            .apply()

        val headers = buildMap {
            channel.referrer?.let { put("Referer", it) }
        }
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(channel.userAgent ?: DEFAULT_UA)
            .setAllowCrossProtocolRedirects(true)
            .setDefaultRequestProperties(headers)

        val item = MediaItem.Builder().setUri(channel.url).apply {
            if (channel.url.contains(".m3u8", ignoreCase = true)) {
                setMimeType(MimeTypes.APPLICATION_M3U8)
            }
        }.build()
        val mediaSource = DefaultMediaSourceFactory(this)
            .setDataSourceFactory(http)
            .createMediaSource(item)

        handler.removeCallbacks(hideStatus)
        status.visibility = View.GONE
        player.setMediaSource(mediaSource)
        player.prepare()
        player.play()
        adapter.playingNumber = channel.number

        // A tvg-id is not a DVB Service ID. Only show a real SID if provided.
        sid.text = channel.sid?.let { "SID:$it" } ?: "SID:—"
        showBanner(channel)
    }

    private fun zap(direction: Int) {
        if (visible.isEmpty()) return
        val current = visible.indexOfFirst { it.number == playing?.number }
        val next = ((if (current < 0) 0 else current) + direction + visible.size) % visible.size
        adapter.selected = next
        list.scrollToPosition(next)
        playChannel(visible[next])
    }

    private fun jumpToNumber() {
        val number = typed.toIntOrNull()
        typed = ""
        numberBox.visibility = View.GONE
        val channel = all.firstOrNull { it.number == number }
        if (channel == null) {
            showStatus("رقم القناة غير موجود")
            return
        }
        if (searchQuery.isNotBlank() || (groupIdx != 0 && channel.group != groups[groupIdx])) {
            searchQuery = ""
            groupIdx = 0
            applyGroup()
        }
        val position = visible.indexOfFirst { it.number == channel.number }
        if (position >= 0) {
            adapter.selected = position
            list.scrollToPosition(position)
        }
        playChannel(channel)
    }

    private fun applyGroup() {
        visible = when {
            searchQuery.isNotBlank() -> all.filter {
                it.name.contains(searchQuery, ignoreCase = true) ||
                    it.group.contains(searchQuery, ignoreCase = true)
            }
            groupIdx == 0 -> all
            else -> all.filter { it.group == groups[groupIdx] }
        }
        adapter.items = visible
        groupTitle.text = if (searchQuery.isNotBlank()) "بحث: $searchQuery" else groups[groupIdx]
        countText.text = "${visible.size} قناة"
        val index = visible.indexOfFirst { it.number == playing?.number }.coerceAtLeast(0)
        adapter.selected = index
        if (visible.isNotEmpty()) list.scrollToPosition(index)
    }

    private fun switchGroup(direction: Int) {
        if (groups.size < 2) return
        searchQuery = ""
        groupIdx = (groupIdx + direction + groups.size) % groups.size
        applyGroup()
        keepPanel()
    }

    private fun showPanel() {
        panel.visibility = View.VISIBLE
        keepPanel()
    }

    private fun keepPanel() {
        handler.removeCallbacks(hidePanel)
        handler.postDelayed(hidePanel, PANEL_TIMEOUT)
    }

    private fun togglePanel() {
        if (panel.visibility == View.VISIBLE) {
            panel.visibility = View.GONE
        } else {
            showPanel()
        }
    }

    private fun showBanner(channel: Channel) {
        bNum.text = channel.number.toString().padStart(4, '0')
        bName.text = channel.name
        bGroup.text = channel.group
        bClock.text = SimpleDateFormat("hh:mm a", Locale("ar")).format(Date())
        banner.visibility = View.VISIBLE
        handler.removeCallbacks(hideBanner)
        handler.postDelayed(hideBanner, BANNER_TIMEOUT)
    }

    private fun showStatus(message: String, autoHide: Boolean = true) {
        handler.removeCallbacks(hideStatus)
        status.text = message
        status.visibility = View.VISIBLE
        if (autoHide) handler.postDelayed(hideStatus, 4_000L)
    }

    private fun selectSource(index: Int) {
        sourceIndex = index
        prefs.edit().putInt("source_index", index).apply()
        loadPlaylist()
    }

    private fun openSources() {
        val options = (sources.map { it.label } +
            listOf("إضافة رابط M3U خاص…", "تحديث القائمة الحالية"))
        AlertDialog.Builder(this)
            .setTitle("اختر مصدر القنوات - ${sourceLabel()}")
            .setItems(options.toTypedArray()) { _, selected ->
                when (selected) {
                    sources.size -> promptCustomUrl()
                    sources.size + 1 -> loadPlaylist()
                    else -> selectSource(selected)
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun promptCustomUrl() {
        val input = EditText(this).apply {
            hint = "https://example.org/channels.m3u"
            setText(prefs.getString("custom_url", ""))
            setSingleLine()
            selectAll()
        }
        AlertDialog.Builder(this)
            .setTitle("رابط قائمة M3U")
            .setView(input)
            .setPositiveButton("حفظ وتشغيل") { _, _ ->
                val value = input.text.toString().trim()
                if (value.startsWith("https://", true) || value.startsWith("http://", true)) {
                    prefs.edit().putString("custom_url", value).apply()
                    selectSource(sources.size)
                } else {
                    showStatus("أدخل رابطًا يبدأ بـ https:// أو http://")
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun openSearch() {
        val input = EditText(this).apply {
            hint = "اسم القناة أو الباقة"
            setSingleLine()
            setText(searchQuery)
        }
        AlertDialog.Builder(this)
            .setTitle("بحث في ${all.size} قناة")
            .setView(input)
            .setPositiveButton("بحث") { _, _ ->
                searchQuery = input.text.toString().trim()
                groupIdx = 0
                applyGroup()
                showPanel()
                if (visible.isEmpty()) showStatus("لا توجد نتائج")
            }
            .setNeutralButton("إظهار الكل") { _, _ ->
                searchQuery = ""
                groupIdx = 0
                applyGroup()
                showPanel()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val digit = when (keyCode) {
            in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> keyCode - KeyEvent.KEYCODE_0
            in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 ->
                keyCode - KeyEvent.KEYCODE_NUMPAD_0
            else -> null
        }
        if (digit != null) {
            val maxDigits = maxOf(4, all.size.toString().length)
            if (typed.length < maxDigits) typed += digit
            numberBox.text = typed.padStart(maxDigits, '-')
            numberBox.visibility = View.VISIBLE
            handler.removeCallbacks(commitNumber)
            handler.postDelayed(commitNumber, 1_800L)
            return true
        }

        val panelOpen = panel.visibility == View.VISIBLE
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> {
                if (panelOpen && keyCode == KeyEvent.KEYCODE_DPAD_UP) moveSelection(-1)
                else zap(1)
                return true
            }
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                if (panelOpen && keyCode == KeyEvent.KEYCODE_DPAD_DOWN) moveSelection(1)
                else zap(-1)
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> if (panelOpen) {
                switchGroup(-1)
                return true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> if (panelOpen) {
                switchGroup(1)
                return true
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (typed.isNotBlank()) {
                    handler.removeCallbacks(commitNumber)
                    jumpToNumber()
                } else if (panelOpen && adapter.selected in visible.indices) {
                    playChannel(visible[adapter.selected])
                } else {
                    showPanel()
                }
                return true
            }
            KeyEvent.KEYCODE_INFO -> {
                playing?.let { showBanner(it) }
                return true
            }
            KeyEvent.KEYCODE_MENU -> {
                openSources()
                return true
            }
            KeyEvent.KEYCODE_SEARCH -> {
                openSearch()
                return true
            }
            KeyEvent.KEYCODE_BACK -> if (panelOpen) {
                panel.visibility = View.GONE
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun moveSelection(direction: Int) {
        if (visible.isEmpty()) return
        adapter.selected = (adapter.selected + direction + visible.size) % visible.size
        list.scrollToPosition(adapter.selected)
        keepPanel()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) goFullscreen()
    }

    override fun onStop() {
        super.onStop()
        player.pause()
    }

    override fun onStart() {
        super.onStart()
        if (playing != null) player.play()
    }

    override fun onDestroy() {
        loadJob?.cancel()
        handler.removeCallbacksAndMessages(null)
        player.release()
        super.onDestroy()
    }
}
