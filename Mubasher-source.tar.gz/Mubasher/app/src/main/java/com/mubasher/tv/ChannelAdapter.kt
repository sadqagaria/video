package com.mubasher.tv

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ChannelAdapter(private val onClick: (Int) -> Unit) :
    RecyclerView.Adapter<ChannelAdapter.VH>() {

    var items: List<Channel> = emptyList()
        set(value) { field = value; notifyDataSetChanged() }

    var selected = 0
        set(value) {
            val old = field
            field = value
            if (old in items.indices) notifyItemChanged(old)
            if (value in items.indices && value != old) notifyItemChanged(value)
        }

    var playingNumber = -1
        set(value) {
            val old = items.indexOfFirst { it.number == field }
            field = value
            val new = items.indexOfFirst { it.number == value }
            if (old >= 0) notifyItemChanged(old)
            if (new >= 0 && new != old) notifyItemChanged(new)
        }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val mark: TextView = view.findViewById(R.id.mark)
        val num: TextView = view.findViewById(R.id.num)
        val name: TextView = view.findViewById(R.id.name)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val channel = items[position]
        val isSelected = position == selected
        holder.num.text = channel.number.toString().padStart(4, '0')
        holder.name.text = channel.name
        holder.mark.text = if (channel.number == playingNumber) "▶" else "✿"
        holder.itemView.setBackgroundResource(
            if (isSelected) R.drawable.row_selected else 0
        )
        val textColor = if (isSelected) Color.BLACK else Color.WHITE
        holder.num.setTextColor(textColor)
        holder.name.setTextColor(textColor)
        holder.itemView.setOnClickListener {
            val actualPosition = holder.bindingAdapterPosition
            if (actualPosition != RecyclerView.NO_POSITION) onClick(actualPosition)
        }
    }
}
