#!/usr/bin/env python3
"""Refresh bundled legal/free-access IPTV playlist from public community indices.

Sources are indexes of publicly available stream URLs, not proof of rebroadcast
rights. Individual links may be geo-restricted or unavailable. Never bypass
DRM, authentication or subscriptions. Offline fallback is left intact if fetch fails.
"""
from __future__ import annotations

import argparse
import pathlib
import re
import sys
import urllib.error
import urllib.request
from urllib.parse import urlsplit

SOURCES = (
    ("الوطن العربي", "https://iptv-org.github.io/iptv/regions/arab.m3u"),
    ("اللغة العربية", "https://iptv-org.github.io/iptv/languages/ara.m3u"),
)
DEFAULT_PATH = pathlib.Path(__file__).resolve().parents[1] / "app/src/main/assets/channels.m3u"
MAX_BYTES = 8 * 1024 * 1024
UA = "Mubasher-Channel-Catalog/1.2 (+https://github.com/iptv-org/iptv)"
EXTINF = re.compile(r'^#EXTINF:', re.IGNORECASE)
ATTR = re.compile(r'([\w-]+)="([^"]*)"')
GROUP = re.compile(r'group-title="[^"]*"')


def read_playlist(url: str) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "text/plain, */*"})
    with urllib.request.urlopen(req, timeout=30) as response:
        content = response.read(MAX_BYTES + 1)
        if len(content) > MAX_BYTES:
            raise ValueError("Playlist exceeded size limit")
        return content.decode("utf-8-sig", errors="replace")


def extract_channels(contents: str, default_group: str) -> list[tuple[str, str]]:
    """Return EXTINF plus URL; preserve upstream M3U metadata and group labels."""
    records = []
    info = None
    for raw in contents.splitlines():
        line = raw.strip()
        if EXTINF.match(line):
            info = line
        elif line and not line.startswith('#'):
            if not info:
                continue
            if not line.startswith(("http://", "https://")):
                info = None
                continue
            parsed = urlsplit(line)
            if not parsed.netloc or parsed.username or parsed.password:
                info = None
                continue
            # Drop sources that are likely playlist-to-playlist rather than video.
            # HLS URLs ending .m3u8 are kept; URLs with query tokens are preserved.
            if not GROUP.search(info):
                info = info.replace(',', f' group-title="{default_group}",', 1)
            records.append((info, line))
            info = None
    return records


def merge_playlists(*sources: tuple[str, str]) -> str:
    seen_urls = set()
    records = []
    for group, contents in sources:
        for info, url in extract_channels(contents, group):
            if url in seen_urls:
                continue
            seen_urls.add(url)
            records.append((info, url))
    return "#EXTM3U\n" + "".join(f"{info}\n{url}\n" for info, url in records)


def count_records(contents: str) -> int:
    return len(extract_channels(contents, "عام"))


def main() -> int:
    parser = argparse.ArgumentParser(description="Refresh built-in IPTV M3U fallback")
    parser.add_argument("--output", type=pathlib.Path, default=DEFAULT_PATH)
    parser.add_argument("--min-channels", type=int, default=40)
    args = parser.parse_args()
    fallback = args.output.read_text(encoding="utf-8-sig") if args.output.exists() else "#EXTM3U\n"
    playlists = []
    for group, url in SOURCES:
        try:
            text = read_playlist(url)
            count = count_records(text)
            print(f"Fetched {group}: {count} candidate entries from {url}")
            if count:
                playlists.append((group, text))
        except (urllib.error.URLError, ValueError, TimeoutError, OSError) as exc:
            print(f"WARNING: could not download {url}: {exc}", file=sys.stderr)
    if playlists:
        merged = merge_playlists(*playlists)
        count = count_records(merged)
        if count >= args.min_channels:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(merged, encoding="utf-8", newline="\n")
            print(f"Saved {count} unique public-index stream entries to {args.output}")
            return 0
        print(f"WARNING: only {count} streams; keeping checked-in fallback", file=sys.stderr)
    print(f"Kept offline fallback with {count_records(fallback)} channel entries")
    return 0 if count_records(fallback) > 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
