import unittest
from tools.refresh_channels import count_records, extract_channels, merge_playlists


class PlaylistTests(unittest.TestCase):
    def test_valid_entries_and_deduplication(self):
        first = '''#EXTM3U\n#EXTINF:-1 tvg-id="a" group-title="مصر",A\nhttps://publisher.example/A.m3u8\n#EXTINF:-1,B\nhttps://publisher.example/B.m3u8\n'''
        second = '''#EXTM3U\n#EXTINF:-1 group-title="السعودية",Duplicate A\nhttps://publisher.example/A.m3u8\n#EXTINF:-1 group-title="السعودية",C\nhttps://publisher.example/C.m3u8\n'''
        playlist = merge_playlists(("الوطن العربي", first), ("السعودية", second))
        self.assertEqual(count_records(playlist), 3)
        self.assertIn('group-title="مصر"', playlist)
        self.assertIn('group-title="الوطن العربي"', playlist)
        self.assertNotIn('Duplicate A', playlist)

    def test_skip_non_https_ftp_and_credentials(self):
        data = '''#EXTM3U\n#EXTINF:-1,Bad\nftp://foo/bar\n#EXTINF:-1,Secrets\nhttps://user:pass@server.example/playlist.m3u8\n#EXTINF:-1,Good\nhttp://server.example/open.m3u8\n'''
        rows = extract_channels(data, 'مصر')
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0][1], 'http://server.example/open.m3u8')


if __name__ == '__main__':
    unittest.main()
