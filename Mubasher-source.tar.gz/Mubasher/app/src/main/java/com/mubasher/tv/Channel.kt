package com.mubasher.tv

data class Channel(
    val number: Int,
    val name: String,
    val url: String,
    val group: String = "عام",
    val logo: String? = null,
    val userAgent: String? = null,
    val referrer: String? = null,
    val tvgId: String? = null,
    val sid: String? = null
)
