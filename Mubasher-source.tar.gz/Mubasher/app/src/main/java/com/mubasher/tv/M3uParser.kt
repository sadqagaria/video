package com.mubasher.tv

/** Extended M3U parser for public HTTP(S) IPTV playlists. */
object M3uParser {
    private val attributes = Regex("""([\w-]+)\s*=\s*"([^"]*)"""")

    fun parse(text: String): List<Channel> {
        val channels = ArrayList<Channel>()
        var name: String? = null
        var group = "عام"
        var logo: String? = null
        var userAgent: String? = null
        var referrer: String? = null
        var tvgId: String? = null
        var sid: String? = null

        for (raw in text.lineSequence()) {
            val line = raw.trim().removePrefix("\uFEFF")
            when {
                line.isBlank() || line.startsWith("#EXTM3U") -> Unit
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    name = null
                    group = "عام"
                    logo = null
                    userAgent = null
                    referrer = null
                    tvgId = null
                    sid = null
                    val attrs = attributes.findAll(line)
                        .associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                    name = line.substringAfterLast(",", "").trim()
                        .ifBlank { attrs["tvg-name"]?.trim().orEmpty() }
                        .ifBlank { "قناة" }
                    group = attrs["group-title"]?.takeIf { it.isNotBlank() } ?: "عام"
                    logo = attrs["tvg-logo"]?.takeIf { it.isNotBlank() }
                    tvgId = attrs["tvg-id"]?.takeIf { it.isNotBlank() }
                    sid = (attrs["sid"] ?: attrs["tvg-sid"])?.takeIf { it.isNotBlank() }
                    userAgent = attrs["http-user-agent"]?.takeIf { it.isNotBlank() }
                    referrer = attrs["http-referrer"]?.takeIf { it.isNotBlank() }
                }
                line.startsWith("#EXTGRP:", ignoreCase = true) ->
                    group = line.substringAfter(":").trim().ifBlank { "عام" }
                line.startsWith("#EXTVLCOPT:http-user-agent=", ignoreCase = true) ->
                    userAgent = line.substringAfter("=")
                line.startsWith("#EXTVLCOPT:http-referrer=", ignoreCase = true) ->
                    referrer = line.substringAfter("=")
                line.startsWith("#") -> Unit
                else -> {
                    if (line.startsWith("https://", ignoreCase = true) ||
                        line.startsWith("http://", ignoreCase = true)
                    ) {
                        channels.add(
                            Channel(
                                number = channels.size + 1,
                                name = name ?: "قناة ${channels.size + 1}",
                                url = line, group = group, logo = logo,
                                userAgent = userAgent, referrer = referrer,
                                tvgId = tvgId, sid = sid
                            )
                        )
                    }
                    name = null
                    group = "عام"
                    logo = null
                    userAgent = null
                    referrer = null
                    tvgId = null
                    sid = null
                }
            }
        }
        return channels
    }
}
